﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace database
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conexão;

            conexão = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=banco00;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        
            conexão.Open();

            Console.WriteLine("on");

            var sSQL = conexão.CreateCommand();

            //sSQL.CommandText = "INSERT INTO Exemplo (Nome, Sobrenome) VALUES ('Roberto', 'Bastos')";

            //sSQL.ExecuteNonQuery();

            sSQL.CommandText = "SELECT * FROM Exemplo";

            var result = sSQL.ExecuteReader();

            while (result.Read())
            {
                Console.WriteLine($"{result["Nome"]} - {result["Sobrenome"]}");
            }

            conexão.Close();

            Console.WriteLine("off");


        }
    }
}
