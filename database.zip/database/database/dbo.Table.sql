﻿CREATE TABLE [dbo].[Exemplo]
(
	[Id] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
	[Nome] NVARCHAR(MAX),
	[Sobrenome] NVARCHAR(MAX)
)
