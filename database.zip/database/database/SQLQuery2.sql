﻿insert into Exemplo (Nome, Sobrenome) values ('Lucas','Zanon')
insert into Exemplo (Nome, Sobrenome) values ('Clica','freifrei')
insert into Exemplo (Nome, Sobrenome) values ('mano','henri')