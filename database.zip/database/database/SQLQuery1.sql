﻿INSERT INTO Exemplo (Nome, SObrenome)
VALUES ('Lucas Zanon')