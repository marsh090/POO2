﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIExemplo01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClick2_Click(object sender, EventArgs e)
        {
            lblClicks.Text = 0.ToString();
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            int contador = 0;
            contador = int.Parse(lblClicks.Text) + 1;
            lblClicks.Text = contador.ToString();
        }
    }
}
