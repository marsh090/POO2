﻿namespace GUIExemplo01
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblContagedeClicks = new System.Windows.Forms.Label();
            this.btnClick = new System.Windows.Forms.Button();
            this.lblClicks = new System.Windows.Forms.Label();
            this.btnClick2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblContagedeClicks
            // 
            this.lblContagedeClicks.AutoSize = true;
            this.lblContagedeClicks.BackColor = System.Drawing.Color.Transparent;
            this.lblContagedeClicks.Font = new System.Drawing.Font("Papyrus", 30F, System.Drawing.FontStyle.Bold);
            this.lblContagedeClicks.Location = new System.Drawing.Point(568, 9);
            this.lblContagedeClicks.Name = "lblContagedeClicks";
            this.lblContagedeClicks.Size = new System.Drawing.Size(284, 128);
            this.lblContagedeClicks.TabIndex = 0;
            this.lblContagedeClicks.Text = "Contagem de \r\n      rick rolls";
            // 
            // btnClick
            // 
            this.btnClick.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnClick.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClick.Location = new System.Drawing.Point(632, 191);
            this.btnClick.Name = "btnClick";
            this.btnClick.Size = new System.Drawing.Size(135, 85);
            this.btnClick.TabIndex = 1;
            this.btnClick.Text = "Rick Rollada";
            this.btnClick.UseVisualStyleBackColor = false;
            this.btnClick.Click += new System.EventHandler(this.btnClick_Click);
            // 
            // lblClicks
            // 
            this.lblClicks.AutoSize = true;
            this.lblClicks.BackColor = System.Drawing.Color.Transparent;
            this.lblClicks.Font = new System.Drawing.Font("Papyrus", 25.75F, System.Drawing.FontStyle.Bold);
            this.lblClicks.Location = new System.Drawing.Point(679, 133);
            this.lblClicks.Name = "lblClicks";
            this.lblClicks.Size = new System.Drawing.Size(45, 55);
            this.lblClicks.TabIndex = 2;
            this.lblClicks.Text = "0";
            // 
            // btnClick2
            // 
            this.btnClick2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnClick2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClick2.Location = new System.Drawing.Point(632, 294);
            this.btnClick2.Name = "btnClick2";
            this.btnClick2.Size = new System.Drawing.Size(135, 85);
            this.btnClick2.TabIndex = 3;
            this.btnClick2.Text = "Reset";
            this.btnClick2.UseVisualStyleBackColor = false;
            this.btnClick2.Click += new System.EventHandler(this.btnClick2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(864, 441);
            this.Controls.Add(this.btnClick2);
            this.Controls.Add(this.lblClicks);
            this.Controls.Add(this.btnClick);
            this.Controls.Add(this.lblContagedeClicks);
            this.Font = new System.Drawing.Font("Papyrus", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "Form1";
            this.Text = "sexo?";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblContagedeClicks;
        private System.Windows.Forms.Button btnClick;
        private System.Windows.Forms.Label lblClicks;
        private System.Windows.Forms.Button btnClick2;
    }
}

